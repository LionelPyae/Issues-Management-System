<?php
define('DB_Conn', TRUE);
require_once './DB/DBConn.php';

define('Function', TRUE);
require_once './DB/Function.php';

if ($_GET["msg"] == "incorrect") {
    $err = "Email or Password is Incorrect!!";
} else if ($_GET["msg"] == "notapproved") {
    $err = "User is Not Approved!!";
}
?>
<!DOCTYPE HTML>
<html>
    <head>
        <title>Admin Login</title>
        <?php require_once './Links.php'; ?>
    </head> 

    <body class="sign-in-up">
        <section>
            <div id="page-wrapper" class="sign-in-wrapper">
                <div class="graphs">
                    <div class="sign-in-form">                              
                        <div class="signin">
                            <div class="signin-rit">
                                <?php if ($_GET["msg"] != "") { ?>
                                    <div class="alert alert-danger" role="alert" style="width: 88%;">
                                        <?php echo $err; ?>
                                    </div>
                                    <?php
                                }
                                ?>
                                <div class="clearfix"> </div>
                            </div>
                            <center><img src="./images/heineken.png" width="200px" htinght="200px"></center>
                            <form method="POST" action="php/SignIn.php">
                                <div class="log-input">
                                    <div class="log-input-left">
                                        <input type="text" class="user" name="Email" placeholder="Email" required="" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$"/>
                                    </div>
                                    <div class="clearfix"> </div>
                                </div>
                                <div class="log-input">
                                    <div class="log-input-left">
                                        <input type="password" name="Password" class="lock" placeholder="Password" required="" pattern="[^'\x22\x2D\x2B]+"/>
                                    </div>
                                    <div class="clearfix"> </div>
                                </div>
                                <input type="submit" name="Submit" value="Login to your account">
                            </form>	 
                        </div>
                    </div>
                </div>
            </div>
            <!--footer section start-->
            <?php require_once './Footer.php'; ?>
            <!--footer section end-->
        </section>
    </body>
</html>
