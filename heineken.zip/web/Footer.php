<footer>
    <p>Developed by <a href="#" target="_blank">W.A.B.</a>[<a href="tel:09256096751">09256096751</a>],[<a href="mailto:wabmagway@gmail.com?Subject=Hello">wabmagway@gmail.com</a>]</p>
</footer>

<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>

<script>
    $(".auto-hide").delay(3000).slideUp();
</script>

<!--For Category hide and view-->

