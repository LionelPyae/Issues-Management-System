<?php
define('Login_Check', TRUE);
require_once './DB/check_login.php';
?>
<!DOCTYPE HTML>
<html>
    <head>
        <?php require_once './Links.php'; ?>
    </head> 

    <body class="sticky-header left-side-collapsed"  onload="initMap()">
        <section>
            <!-- left side start-->
            <?php require_once './LeftBar.php'; ?>
            <!-- left side end-->

            <!-- main content start-->
            <div class="main-content">
                <!-- header-starts -->
                <?php require_once './Header.php'; ?>
                <!-- //header-ends -->
                <div id="page-wiper">
                	<center><img src="images/heineken.png" height="200px"></img></center><br><br>
<?php
$link = mysqli_connect("127.0.0.1", "root", "", "dcs_db");
$result= mysqli_query($link, "SELECT * from Services");
$data=mysqli_num_rows($result);
$dataPoints1 = array( 
	array("label" => "Monday",  "y" => $data ),
	array("label" => "Tuesday", "y" => 5),
	array("label" => "Wednesday", "y" => 7 ),
	array("label" => "Thursday",  "y" => 2 ),
	array("label" => "Friday",  "y" => 2 ),
	array("label" => "Saturday",  "y" => 2 ),
	array("label" => "Sunday",  "y" => 2 )
);
mysqli_close($link); 
 
?>
<script>
window.onload = function() {
 
var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	theme: "light2",
	title: {
		text: "Average DCS Graph"
	},
	axisX: {
		title: "Days"
	},
	axisY: {
		title: "Issue",
		gridThickness: 2,
		lineThickness: 1,
		includeZero: false
	},
	toolTip: {
		shared: true
	},
	data: [{
		type: "column",
		name: "Number of Issue",
		dataPoints: <?php echo json_encode($dataPoints1, JSON_NUMERIC_CHECK); ?>
	},
	{
		type: "error",
		name: "Acceptable Variation",
		yValueFormatString: "#,##0.00 BPM",
		dataPoints: <?php echo json_encode($dataPoints2, JSON_NUMERIC_CHECK); ?>
	}]
});
chart.render();
 
}
</script>
<div id="chartContainer" style="height: 370px; width: 100%;"></div>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
        </section>
</div></div>
    </body>
</html>
