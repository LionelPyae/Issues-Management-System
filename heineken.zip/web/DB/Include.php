<?php

define('DB_Conn', TRUE);
require_once 'DB/DBConn.php';

define('Function', TRUE);
require_once 'DB/Function.php';
?>